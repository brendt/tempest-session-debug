console.log('🌊')
